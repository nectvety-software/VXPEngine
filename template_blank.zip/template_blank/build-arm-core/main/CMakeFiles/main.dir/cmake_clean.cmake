file(REMOVE_RECURSE
  "CMakeFiles/main.dir/__/common/gccmain.c.obj"
  "CMakeFiles/main.dir/__/common/gccmain.c.obj.d"
  "CMakeFiles/main.dir/__/src/main.c.obj"
  "CMakeFiles/main.dir/__/src/main.c.obj.d"
  "main.axf"
  "main.axf.manifest"
  "main.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/main.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
