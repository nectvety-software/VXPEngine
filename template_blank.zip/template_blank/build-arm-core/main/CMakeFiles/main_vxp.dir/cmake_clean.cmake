file(REMOVE_RECURSE
  "BlankApp.pdb"
  "BlankApp.vxp"
  "CMakeFiles/main_vxp.dir/null_main_vxp.cpp.obj"
  "CMakeFiles/main_vxp.dir/null_main_vxp.cpp.obj.d"
  "null_main_vxp.cpp"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/main_vxp.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
