file(REMOVE_RECURSE
  "BlankApp.vxp"
)
