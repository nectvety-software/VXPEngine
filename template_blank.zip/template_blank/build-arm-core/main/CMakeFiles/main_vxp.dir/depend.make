# Empty dependencies file for main_vxp.
# This may be replaced when dependencies are built.
