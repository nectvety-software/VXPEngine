# Empty dependencies file for coremre.
# This may be replaced when dependencies are built.
