CMakeFiles/coremre.dir/D_/MRE/VXPEngine/packaging/coremre/2.0.0/src/gameplay/StateMachine.cpp.obj: \
 D:\MRE\VXPEngine\packaging\coremre\2.0.0\src\gameplay\StateMachine.cpp \
 D:\MRE\VXPEngine\packaging\coremre\2.0.0\include/gameplay/StateMachine.h \
 D:\MRE\VXPEngine\packaging\coremre\2.0.0\include/platforms/PlatformDefaults.h
