CMakeFiles/coremre.dir/D_/MRE/VXPEngine/packaging/coremre/2.0.0/src/input/TouchStateMachine.cpp.obj: \
 D:\MRE\VXPEngine\packaging\coremre\2.0.0\src\input\TouchStateMachine.cpp \
 D:\MRE\VXPEngine\packaging\coremre\2.0.0\include/input/TouchStateMachine.h \
 C:/msys64/mingw64/arm-none-eabi/include/c++/13.3.0/cstdint \
 C:/msys64/mingw64/arm-none-eabi/include/c++/13.3.0/arm-none-eabi/thumb/nofp/bits/c++config.h \
 C:/msys64/mingw64/arm-none-eabi/include/c++/13.3.0/arm-none-eabi/thumb/nofp/bits/os_defines.h \
 C:/msys64/mingw64/arm-none-eabi/include/c++/13.3.0/arm-none-eabi/thumb/nofp/bits/cpu_defines.h \
 C:/msys64/mingw64/arm-none-eabi/include/c++/13.3.0/pstl/pstl_config.h \
 C:/msys64/mingw64/lib/gcc/arm-none-eabi/13.3.0/include/stdint.h \
 C:/msys64/mingw64/arm-none-eabi/include/stdint.h \
 C:/msys64/mingw64/arm-none-eabi/include/machine/_default_types.h \
 C:/msys64/mingw64/arm-none-eabi/include/sys/features.h \
 C:/msys64/mingw64/arm-none-eabi/include/_newlib_version.h \
 C:/msys64/mingw64/arm-none-eabi/include/sys/_intsup.h \
 C:/msys64/mingw64/arm-none-eabi/include/sys/_stdint.h \
 D:\MRE\VXPEngine\packaging\coremre\2.0.0\include/input/TouchEvent.h \
 D:\MRE\VXPEngine\packaging\coremre\2.0.0\include/input/TouchEventTypes.h \
 D:\MRE\VXPEngine\packaging\coremre\2.0.0\include/input/TouchEventQueue.h
