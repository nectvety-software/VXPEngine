CMakeFiles/coremre.dir/D_/MRE/VXPEngine/packaging/coremre/2.0.0/src/platforms/PlatformCapabilities.cpp.obj: \
 D:\MRE\VXPEngine\packaging\coremre\2.0.0\src\platforms\PlatformCapabilities.cpp \
 D:\MRE\VXPEngine\packaging\coremre\2.0.0\include/platforms/PlatformCapabilities.h \
 D:\MRE\VXPEngine\packaging\coremre\2.0.0\include/platforms/PlatformDefaults.h
