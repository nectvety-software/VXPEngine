file(REMOVE_RECURSE
  "libcoremre.a"
)
