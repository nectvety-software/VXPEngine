file(REMOVE_RECURSE
  "CMakeFiles/mreapi.dir/null.cpp.obj"
  "CMakeFiles/mreapi.dir/null.cpp.obj.d"
  "libmreapi.a"
  "libmreapi.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/mreapi.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
