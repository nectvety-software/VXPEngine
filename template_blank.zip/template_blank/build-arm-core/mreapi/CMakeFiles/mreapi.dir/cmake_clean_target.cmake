file(REMOVE_RECURSE
  "libmreapi.a"
)
