# Empty dependencies file for mreapi.
# This may be replaced when dependencies are built.
