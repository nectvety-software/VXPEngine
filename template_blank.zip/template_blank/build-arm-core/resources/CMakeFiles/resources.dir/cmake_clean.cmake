file(REMOVE_RECURSE
  "CMakeFiles/resources.dir/null.cpp.obj"
  "CMakeFiles/resources.dir/null.cpp.obj.d"
  "null.cpp"
  "resources.pdb"
  "resources.res"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/resources.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
