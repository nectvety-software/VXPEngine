file(REMOVE_RECURSE
  "resources.res"
)
