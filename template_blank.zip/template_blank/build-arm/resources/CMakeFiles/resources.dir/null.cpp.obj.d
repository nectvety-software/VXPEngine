resources/CMakeFiles/resources.dir/null.cpp.obj: \
 D:\MRE\VXPEngine\template_blank\build-arm\resources\null.cpp
