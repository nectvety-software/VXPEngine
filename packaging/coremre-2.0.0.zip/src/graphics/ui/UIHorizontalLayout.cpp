#include "core/EngineModules.h"
#if PIXELROOT32_ENABLE_UI_SYSTEM

/*
 * Copyright (c) 2026 PixelRoot32
 * Licensed under the MIT License
 */
#include "graphics/ui/UIHorizontalLayout.h"
#include "graphics/ui/UIButton.h"
#include "graphics/ui/UICheckbox.h"
#include "graphics/Renderer.h"
#include "core/Scene.h"
#include <algorithm>
#include "math/MathUtil.h"

namespace pixelroot32::graphics::ui {

    namespace math = pixelroot32::math;
    using math::Vector2;
    using math::Scalar;
    using math::toScalar;
        
    UIHorizontalLayout::UIHorizontalLayout(Scalar x, Scalar y, int w, int h)
        : UILayout(x, y, w, h) {
        lastScrollOffset = Scalar(0);
        needsClear = true; // Clear on first draw
    }

    UIHorizontalLayout::UIHorizontalLayout(Vector2 position, int w, int h)
        : UILayout(position, w, h) {
        lastScrollOffset = Scalar(0);
        needsClear = true; // Clear on first draw
    }

    void UIHorizontalLayout::addElement(UIElement* element) {
        if (!element) return;
        
        // Check if element is already in the layout
        auto it = std::find(elements.begin(), elements.end(), element);
        if (it != elements.end()) return;
        
        elements.push_back(element);
        updateLayout();
    }

    void UIHorizontalLayout::removeElement(UIElement* element) {
        if (!element) return;
        
        auto it = std::find(elements.begin(), elements.end(), element);
        if (it != elements.end()) {
            elements.erase(it);
            // If removed element was selected, adjust selection
            if (selectedIndex >= static_cast<int>(elements.size())) {
                selectedIndex = static_cast<int>(elements.size()) - 1;
            }
            updateLayout();
        }
    }

    void UIHorizontalLayout::calculateContentWidth() {
        contentWidth = padding * Scalar(2); // Left and right padding
        
        for (size_t i = 0; i < elements.size(); ++i) {
            contentWidth += Scalar(elements[i]->width);
            if (i < elements.size() - 1) {
                contentWidth += spacing; // Spacing between elements (not after last)
            }
        }
    }

    void UIHorizontalLayout::updateLayout() {
        calculateContentWidth();
        
        // Check if scroll changed (for performance optimization: only clear when needed)
        // Use a small threshold to catch all scroll changes, including instant scrolls
        if (math::abs(scrollOffset - lastScrollOffset) > toScalar(0.01f)) {
            needsClear = true;
            lastScrollOffset = scrollOffset;
        }
        
        Scalar currentX = position.x + padding - scrollOffset;
        Scalar viewportLeft = position.x;
        Scalar viewportRight = position.x + Scalar(width);
        
        for (size_t i = 0; i < elements.size(); ++i) {
            UIElement* elem = elements[i];
            
            // Set Y position (centered or top-aligned based on layout height)
            Scalar elemY = position.y + padding;
            if (toScalar(elem->height) < toScalar(height) - (padding * toScalar(2))) {
                // Center element vertically if it's smaller than layout height
                elemY = position.y + (toScalar(height) - toScalar(elem->height)) / toScalar(2);
            }
            
            elem->setPosition(currentX, elemY);
            
            // Update visibility immediately based on current position
            Scalar elemLeft = currentX;
            Scalar elemRight = currentX + Scalar(elem->width);
            bool visible = (elemLeft < viewportRight && elemRight > viewportLeft);
            elem->setVisible(visible);
            
            currentX += Scalar(elem->width) + spacing;
        }
        
        clampScrollOffset();
    }

    void UIHorizontalLayout::setButtonStyle(pixelroot32::graphics::Color selectedTextCol,
                                            pixelroot32::graphics::Color selectedBgCol,
                                            pixelroot32::graphics::Color unselectedTextCol,
                                            pixelroot32::graphics::Color unselectedBgCol) {
        selectedTextColor = selectedTextCol;
        selectedBgColor = selectedBgCol;
        unselectedTextColor = unselectedTextCol;
        unselectedBgColor = unselectedBgCol;
        
        // Update styles of existing buttons
        setSelectedIndex(selectedIndex); // This will update all button styles
    }

    void UIHorizontalLayout::clampScrollOffset() {
        Scalar maxScroll = contentWidth - Scalar(width);
        if (maxScroll < Scalar(0)) maxScroll = Scalar(0);
        
        if (scrollOffset < Scalar(0)) {
            scrollOffset = Scalar(0);
        } else if (scrollOffset > maxScroll) {
            scrollOffset = maxScroll;
        }
        
        targetScrollOffset = scrollOffset;
    }

    void UIHorizontalLayout::updateElementVisibility() {
        Scalar viewportLeft = position.x;
        Scalar viewportRight = position.x + Scalar(width);
        
        for (UIElement* elem : elements) {
            Scalar elemLeft = elem->position.x;
            Scalar elemRight = elem->position.x + Scalar(elem->width);
            
            // Element is visible if it overlaps with viewport
            // Use strict bounds checking to prevent drawing outside viewport
            bool visible = (elemLeft < viewportRight && elemRight > viewportLeft);
            elem->setVisible(visible);
        }
    }

    void UIHorizontalLayout::ensureSelectedVisible() {
        if (selectedIndex < 0 || selectedIndex >= static_cast<int>(elements.size())) {
            return;
        }
        
        // Calculate absolute position of selected element in content space (from left of content)
        Scalar absoluteX = padding;
        for (int i = 0; i < selectedIndex; ++i) {
            absoluteX += Scalar(elements[i]->width) + spacing;
        }
        
        Scalar elemWidth = Scalar(elements[selectedIndex]->width);
        Scalar elemLeft = absoluteX;
        Scalar elemRight = absoluteX + elemWidth;
        
        Scalar viewportWidth = Scalar(width);
        
        // Calculate screen positions with current scroll
        Scalar screenLeft = position.x + padding + elemLeft - scrollOffset;
        Scalar screenRight = position.x + padding + elemRight - scrollOffset;
        Scalar viewportLeft = position.x;
        Scalar viewportRight = position.x + viewportWidth;

        
        // Calculate required scroll offset to make element visible
        Scalar newScrollOffset = scrollOffset;
        bool needsScroll = false;
        
        // If element left is to the left of viewport, scroll left (decrease scroll offset)
        if (screenLeft < viewportLeft) {
            // Scroll so element left aligns with viewport left
            newScrollOffset = elemLeft;
            needsScroll = true;
        }
        // If element right is to the right of viewport, scroll right (increase scroll offset)
        else if (screenRight > viewportRight) {
            // Scroll so element right aligns with viewport right
            newScrollOffset = elemRight - (viewportWidth - padding * Scalar(2));
            needsScroll = true;
        }
        
        // Apply scroll immediately (NES-style: instant scroll on selection change)
        if (needsScroll && UILayout::enableScroll) {
            // Mark for clearing before changing scroll (important for instant scroll)
            needsClear = true;
            scrollOffset = newScrollOffset;
            targetScrollOffset = newScrollOffset;
            lastScrollOffset = newScrollOffset; // Update immediately to prevent false detection
            clampScrollOffset();
            updateLayout();
        }
    }

    void UIHorizontalLayout::setScrollOffset(Scalar offset) {
        // Mark for clearing when scroll changes
        if (math::abs(offset - scrollOffset) > toScalar(0.01f)) {
            needsClear = true;
        }
        scrollOffset = offset;
        targetScrollOffset = offset;
        lastScrollOffset = offset; // Update immediately
        clampScrollOffset();
        updateLayout();
    }

    void UIHorizontalLayout::setSelectedIndex(int index) {
        if (index < -1) index = -1;
        if (index >= static_cast<int>(elements.size())) {
            index = static_cast<int>(elements.size()) - 1;
        }
        
        // Mark for clearing if selection changed (scroll will happen)
        if (selectedIndex != index) {
            needsClear = true;
        }
        
        selectedIndex = index;
        
        // Update element selection states and styles
        for (size_t i = 0; i < elements.size(); ++i) {
            UIElement* elem = elements[i];
            bool isSelected = (static_cast<int>(i) == selectedIndex);
            
            if (elem->getType() == UIElement::UIElementType::BUTTON) {
                UIButton* btn = static_cast<UIButton*>(elem);
                if (btn) {
                    btn->setSelected(isSelected);
                    if (isSelected) {
                        btn->setStyle(selectedTextColor, selectedBgColor, true);
                    } else {
                        btn->setStyle(unselectedTextColor, unselectedBgColor, false);
                    }
                }
            } else if (elem->getType() == UIElement::UIElementType::CHECKBOX) {
                UICheckBox* cb = static_cast<UICheckBox*>(elem);
                if (cb) {
                    cb->setSelected(isSelected);
                    if (isSelected) {
                        cb->setStyle(selectedTextColor, selectedBgColor, true);
                    } else {
                        cb->setStyle(unselectedTextColor, unselectedBgColor, false);
                    }
                }
            }
        }
        
        if (selectedIndex >= 0) {
            ensureSelectedVisible();
        }
    }

    UIElement* UIHorizontalLayout::getSelectedElement() const {
        if (selectedIndex < 0 || selectedIndex >= static_cast<int>(elements.size())) {
            return nullptr;
        }
        return elements[selectedIndex];
    }

    void UIHorizontalLayout::handleInput(const pixelroot32::input::InputManager& input) {
        if (elements.empty()) {
            selectedIndex = -1;
            return;
        }
        
        bool selectionChanged = false;
        
        // Handle LEFT navigation with rising edge detection (workaround for InputManager debounce bug)
        bool isLeft = input.isButtonDown(navLeftButton);
        if (isLeft && !wasLeftPressed) { // LEFT Rising Edge
            if (selectedIndex > 0) {
                selectedIndex--;
                selectionChanged = true;
            } else if (selectedIndex == -1) {
                selectedIndex = static_cast<int>(elements.size()) - 1;
                selectionChanged = true;
            } else {
                selectedIndex = static_cast<int>(elements.size()) - 1; // Wrap to last
                selectionChanged = true;
            }
        }
        wasLeftPressed = isLeft;
        
        // Handle RIGHT navigation with rising edge detection
        bool isRight = input.isButtonDown(navRightButton);
        if (isRight && !wasRightPressed) { // RIGHT Rising Edge
            if (selectedIndex < static_cast<int>(elements.size()) - 1) {
                selectedIndex++;
                selectionChanged = true;
            } else if (selectedIndex == -1) {
                selectedIndex = 0;
                selectionChanged = true;
            } else {
                selectedIndex = 0; // Wrap to first
                selectionChanged = true;
            }
        }
        wasRightPressed = isRight;
        
        if (selectionChanged) {
            setSelectedIndex(selectedIndex);
        }
        
        // Forward input to selected element (for button callbacks and checkbox toggles)
        if (selectedIndex >= 0 && selectedIndex < static_cast<int>(elements.size())) {
            UIElement* selected = elements[selectedIndex];
            if (selected->getType() == UIElement::UIElementType::BUTTON) {
                UIButton* btn = static_cast<UIButton*>(selected);
                if (btn) {
                    btn->handleInput(input);
                }
            } else if (selected->getType() == UIElement::UIElementType::CHECKBOX) {
                UICheckBox* cb = static_cast<UICheckBox*>(selected);
                if (cb) {
                    cb->handleInput(input);
                }
            }
        }
    }

    void UIHorizontalLayout::update(unsigned long deltaTime) {
        // Smooth scroll interpolation (only for manual scrolling, not for selection-based scrolling)
        // Selection-based scrolling is instant (NES-style)
        if (this->UILayout::enableScroll && math::abs(targetScrollOffset - scrollOffset) > toScalar(0.1f)) {
            Scalar delta = targetScrollOffset - scrollOffset;
            Scalar maxDelta = scrollSpeed * toScalar(static_cast<float>(deltaTime));
            
            if (math::abs(delta) <= maxDelta) {
                scrollOffset = targetScrollOffset;
            } else {
                scrollOffset += (delta > toScalar(0.0f) ? maxDelta : -maxDelta);
            }
            
            updateLayout();
        }
        
        // Update child elements
        for (UIElement* elem : elements) {
            if (elem->isEnabled) {
                elem->update(deltaTime);
            }
        }
    }

    void UIHorizontalLayout::draw(pixelroot32::graphics::Renderer& renderer) {
        if (!isVisible) return;
        
        // Save current bypass state and apply fixedPosition if enabled
        bool oldBypass = renderer.isOffsetBypassEnabled();
        if (fixedPosition) {
            renderer.setOffsetBypass(true);
        }
        
        // Performance optimization: Only clear layout area when scroll/selection changed
        // This avoids expensive fillRect() call every frame on ESP32
        // However, we must clear when scroll is enabled and there's content to scroll
        bool shouldClear = needsClear;
        if (UILayout::enableScroll && contentWidth > static_cast<float>(width)) {
            // If scroll is enabled and content exceeds viewport, always clear to prevent artifacts
            // This is necessary because elements can move outside viewport
            shouldClear = true;
        }
        
        if (shouldClear) {
            renderer.drawFilledRectangle(static_cast<int>(position.x), static_cast<int>(position.y), 
                                        width, height, pixelroot32::graphics::Color::Black);
            needsClear = false;
        }
        
        // Draw only visible elements (visibility already calculated in updateLayout)
        // Skip double-checking for performance - we trust updateLayout() visibility calculation
        for (UIElement* elem : elements) {
            if (elem->isVisible) {
                elem->draw(renderer);
            }
        }
        
        // Restore bypass state
        if (fixedPosition) {
            renderer.setOffsetBypass(oldBypass);
        }
    }

}

#endif // PIXELROOT32_ENABLE_UI_SYSTEM
