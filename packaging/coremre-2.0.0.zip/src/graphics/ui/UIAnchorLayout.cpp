#include "core/EngineModules.h"
#if PIXELROOT32_ENABLE_UI_SYSTEM

/*
 * Copyright (c) 2026 PixelRoot32
 * Licensed under the MIT License
 */
#include "graphics/ui/UIAnchorLayout.h"
#include "graphics/Renderer.h"
#include <algorithm>

namespace pixelroot32::graphics::ui {

    namespace math = pixelroot32::math;
    using math::Vector2;
    using math::Scalar;
    using math::toScalar;

    UIAnchorLayout::UIAnchorLayout(Scalar x, Scalar y, int w, int h)
        : UILayout(x, y, w, h) {
        screenWidth = w;
        screenHeight = h;
    }

    UIAnchorLayout::UIAnchorLayout(Vector2 position, int w, int h)
        : UILayout(position, w, h) {
        screenWidth = w;
        screenHeight = h;
    }

    void UIAnchorLayout::setScreenSize(int screenW, int screenH) {
        screenWidth = screenW;
        screenHeight = screenH;
        width = screenW;
        height = screenH;
        updateLayout();
    }

    void UIAnchorLayout::addElement(UIElement* element, Anchor anchor) {
        if (!element) return;
        
        // Check if element is already in the layout
        auto it = std::find_if(anchoredElements.begin(), anchoredElements.end(),
            [element](const std::pair<UIElement*, Anchor>& pair) {
                return pair.first == element;
            });
        
        if (it != anchoredElements.end()) return;
        
        anchoredElements.push_back(std::make_pair(element, anchor));
        elements.push_back(element); // Also add to base class vector for compatibility
        updateLayout();
    }

    void UIAnchorLayout::addElement(UIElement* element) {
        // Default to TOP_LEFT if no anchor specified
        addElement(element, Anchor::TOP_LEFT);
    }

    void UIAnchorLayout::removeElement(UIElement* element) {
        if (!element) return;
        
        // Remove from anchored elements
        auto it = std::find_if(anchoredElements.begin(), anchoredElements.end(),
            [element](const std::pair<UIElement*, Anchor>& pair) {
                return pair.first == element;
            });
        
        if (it != anchoredElements.end()) {
            anchoredElements.erase(it);
        }
        
        // Remove from base class vector
        auto baseIt = std::find(elements.begin(), elements.end(), element);
        if (baseIt != elements.end()) {
            elements.erase(baseIt);
        }
        
        updateLayout();
    }

    void UIAnchorLayout::calculateAnchorPosition(UIElement* element, Anchor anchor, Scalar& outX, Scalar& outY) const {
        
        switch (anchor) {
            case Anchor::TOP_LEFT:
                outX = Scalar(0);
                outY = Scalar(0);
                break;
                
            case Anchor::TOP_RIGHT:
                outX = toScalar(screenWidth - element->width);
                outY = Scalar(0);
                break;
                
            case Anchor::BOTTOM_LEFT:
                outX = Scalar(0);
                outY = toScalar(screenHeight - element->height);
                break;
                
            case Anchor::BOTTOM_RIGHT:
                outX = toScalar(screenWidth - element->width);
                outY = toScalar(screenHeight - element->height);
                break;
                
            case Anchor::CENTER:
                outX = toScalar(screenWidth - element->width) / Scalar(2);
                outY = toScalar(screenHeight - element->height) / Scalar(2);
                break;
                
            case Anchor::TOP_CENTER:
                outX = toScalar(screenWidth - element->width) / Scalar(2);
                outY = Scalar(0);
                break;
                
            case Anchor::BOTTOM_CENTER:
                outX = toScalar(screenWidth - element->width) / Scalar(2);
                outY = toScalar(screenHeight - element->height);
                break;
                
            case Anchor::LEFT_CENTER:
                outX = Scalar(0);
                outY = toScalar(screenHeight - element->height) / Scalar(2);
                break;
                
            case Anchor::RIGHT_CENTER:
                outX = toScalar(screenWidth - element->width);
                outY = toScalar(screenHeight - element->height) / Scalar(2);
                break;
        }
    }

    void UIAnchorLayout::updateLayout() {
        // Calculate positions for all anchored elements
        for (const auto& [elem, anchor] : anchoredElements) {
            Scalar elemX, elemY;
            calculateAnchorPosition(elem, anchor, elemX, elemY);
            
            elem->setPosition(elemX, elemY);
            elem->setVisible(isVisible); // Inherit visibility from layout
        }
    }

    void UIAnchorLayout::handleInput(const pixelroot32::input::InputManager& input) {
        // Anchor layout doesn't handle input - elements handle their own input
        // This is intentional: HUD elements typically don't need layout-level navigation
        (void)input; // Suppress unused parameter warning
    }

    void UIAnchorLayout::update(unsigned long deltaTime) {
        // Update child elements
        for (UIElement* elem : elements) {
            if (elem->isEnabled) {
                elem->update(deltaTime);
            }
        }
    }

    void UIAnchorLayout::draw(pixelroot32::graphics::Renderer& renderer) {
        if (!isVisible) return;
        
        // Save current bypass state and apply fixedPosition if enabled
        bool oldBypass = renderer.isOffsetBypassEnabled();
        if (fixedPosition) {
            renderer.setOffsetBypass(true);
        }
        
        // Auto-update screen size if logical resolution changed in renderer
        if (toScalar(renderer.getLogicalWidth()) != screenWidth || 
            toScalar(renderer.getLogicalHeight()) != screenHeight) {
            setScreenSize(renderer.getLogicalWidth(), renderer.getLogicalHeight());
        }
        
        // Draw all elements (no viewport culling needed for HUD elements)
        for (UIElement* elem : elements) {
            if (elem->isVisible) {
                elem->draw(renderer);
            }
        }
        
        // Restore bypass state
        if (fixedPosition) {
            renderer.setOffsetBypass(oldBypass);
        }
    }

}

#endif // PIXELROOT32_ENABLE_UI_SYSTEM
